#ifndef _ERROR_H_
#define _ERROR_H_

#define ERROR_OK 0

#endif

